const mongoose = require('mongoose');

const employeeSchema=mongoose.Schema({
    image:{
        type:String,
        required:true
    },
    employee:{
        type:String,
        required:true
    },
    name:{
        type:String,
        required:true
    },
    department:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true
    },
    date:{
        type:String,
        required:true
    },
    city:{
        type:String,
        required:true
    }
})

const employeedata=mongoose.model("employeesdata",employeeSchema);

module.exports=employeedata;