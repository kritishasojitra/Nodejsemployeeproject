const express=require('express')
const port=2424;

const app = express();
const path = require('path');
const database = require('./config/database');
const employeedata=require('./model/schema');
const multer= require('multer');

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const storage=multer.diskStorage({
    destination:(req,res,cb)=>{
        cb(null,'./Uploads')
    },
    filename:(req,file,cb)=>{
        cb(null,file.originalname);
    }
})

const upload=multer({storage:storage}).single('image')

app.set('view engine', 'ejs');
app.get('/', (req, res) => {
    res.render('home')
})

app.get('/index', (req, res) => {
    res.render('index')
})

app.get('/form.html',(req, res) => {
    res.render('form')
})


app.post('/insert', upload, (req, res) => {
    let image = "";
    if (req.file) {
        image = req.file.path;
    }
    employeedata.create({
        image: image,
        employee: req.body.employee,
        name: req.body.name,
        department: req.body.department,
        email: req.body.email,
        date: req.body.date,
        city: req.body.city,
    }).then(() => {
        console.log("Data insert successfully");
        res.redirect('/table');
    }).catch(err => {
        console.log(err);
    });
});
app.get('/table', (req, res) => {
    employeedata.find({}).then((employeedata) => {
        res.render('table', {
            alldata: employeedata
        });
    }).catch((err) => {
        console.log("Error fetching data:", err);
        res.status(500).send("Error fetching data");
    });
});
app.get('/delete',(req,res)=>{
    let id=req.query.id;

    employeedata.findByIdAndDelete(id).then(()=>{
        return res.redirect('/table')
    })
})
app.get('/edit', (req, res) => {
    let id = req.query.id;
    employeedata.findById(id).then((employee) => {
        res.render("edit", {
            edit: employee // Pass the edit variable correctly
        });
    }).catch((err) => {
        console.log("Error fetching data for edit:", err);
        res.status(500).send("Error fetching data for edit");
    });
});


app.post('/update', upload, (req, res) => {
    let id = req.body.id;
    
  
    if (req.file) {
        var data = {
            image:req.file.path,
          employee: req.body.employee,
          name: req.body.name,
          department: req.body.department,
          email: req.body.email,
          date: req.body.date,
          city: req.body.city,
        }
    }
    else{
        var data = {
          employee: req.body.employee,
          name: req.body.name,
          department: req.body.department,
          email: req.body.email,
          date: req.body.date,
          city: req.body.city,
        }
    }
  
    employeedata.findByIdAndUpdate(id, data)
      .then((updatedData) => {
        console.log("Data successfully updated");
        res.redirect('/table');
      })
      .catch((err) => {
        console.log("Error updating data:", err);
        res.status(500).send("Error updating data");
      });
  });

app.listen(port,()=>{
    console.log("Server started at:-"+port);
})